urlpatterns = [
    path('articles/', include('articles.urls'),
    path('pages/', include('pages.urls'),
]
